@echo 
slmgr /ipk HT6VR-XMPDJ-2VBFV-R9PFY-3VP7R

@echo
slmgr /skms 200.200.4.10

@echo 
slmgr /ato