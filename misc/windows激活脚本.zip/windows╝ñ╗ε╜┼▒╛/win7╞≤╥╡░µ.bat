@echo 
slmgr /ipk 33PXH-7Y6KF-2VJC9-XBBR8-HVTHH

@echo
slmgr /skms 200.200.4.10

@echo 
slmgr /ato