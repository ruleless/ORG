@echo 
slmgr /ipk NPPR9-FWDCX-D2C8J-H872K-2YT43

@echo
slmgr /skms 200.200.4.10

@echo 
slmgr /ato