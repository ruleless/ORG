@echo 
slmgr /ipk 86XWR-BDPWV-TTJJW-67WMM-X6RKR

@echo
slmgr /skms 200.200.4.10

@echo 
slmgr /ato