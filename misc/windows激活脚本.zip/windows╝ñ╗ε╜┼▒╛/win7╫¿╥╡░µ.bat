@echo 
slmgr /ipk FJ82H-XT6CR-J8D7P-XQJJ2-GPDD4

@echo
slmgr /skms 200.200.4.10

@echo 
slmgr /ato