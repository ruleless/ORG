@echo 
slmgr /ipk WC2BQ-8NRM3-FDDYY-2BFGV-KHKQY

@echo
slmgr /skms 200.200.4.10

@echo 
slmgr /ato